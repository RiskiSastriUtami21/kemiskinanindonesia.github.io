define({
  "_themeLabel": "Sklopiva tema",
  "_layout_default": "Podrazumevani raspored",
  "_layout_layout1": "Raspored 1"
});
define({
  "_themeLabel": "Temă cu pliere",
  "_layout_default": "Aspect implicit",
  "_layout_layout1": "Aspectul 1"
});
define({
  "_themeLabel": "Kokkuvolditav kujundus",
  "_layout_default": "Vaikimisi paigutus",
  "_layout_layout1": "Paigutus 1"
});